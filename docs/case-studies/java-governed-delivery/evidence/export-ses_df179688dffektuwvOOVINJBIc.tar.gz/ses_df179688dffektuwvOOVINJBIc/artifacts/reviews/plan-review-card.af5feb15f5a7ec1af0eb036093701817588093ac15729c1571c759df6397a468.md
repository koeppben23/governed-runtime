# FlowGuard Plan Review

**Status:** Ready for plan approval
**Plan version:** v1
**Policy:** team
**Task:** # TICKET: Fix 500 Error on Non-Existent Task Update

## Review Provenance

**Reviewed plan digest:** `af5feb15f5a7ec1af0eb036093701817588093ac15729c1571c759df6397a468`
**Reviewed obligation:** `aacc9732-4753-400c-a06b-c32a0c03ede9`

## Verification

2 plan claim(s) declared
2 critical

✓ 2 critical claim(s) with counterexample checks

Status: AWAITING_EVIDENCE
Approval evidence: Not recorded

## Claim Declarations Under Approval

- **c110cb6d-e8f4-5605-a7b7-2b362b614647** (critical)
  - Statement: A PUT /tasks/{id} request for an unknown task id returns HTTP 404 with a JSON error body whose taskId equals the requested id instead of propagating a NullPointerException as HTTP 500.
  - Authority section: implementation-step-1
  - Claim scope: specific_behavior
  - Positive evidence check: build
  - Counterexample (adversarial) check: test; assertion providerId: junit; localId: com.example.taskmanager.controller.TaskControllerTest#update_taskNotFound_returns404
  - Structural surface: none
  - Mutation profile: none
  - Risk triggers covered: none
- **a29b3469-86b4-5080-9e74-d219bfe69bb7** (critical)
  - Statement: A PUT /tasks/{id} request for an existing task still returns HTTP 200 with the submitted title and priority applied.
  - Authority section: implementation-step-1
  - Claim scope: specific_behavior
  - Positive evidence check: test
  - Counterexample (adversarial) check: build; assertion providerId: junit; localId: com.example.taskmanager.controller.TaskControllerTest#update_existing_task_returns_ok
  - Structural surface: none
  - Mutation profile: none
  - Risk triggers covered: none

## Proposed Plan

### Implementation Plan

> **Objective:** Make `PUT /tasks/{id}` fail closed with HTTP 404 and a task-id-bearing error body when the task does not exist, and activate the disabled controller regression test that proves it. | **Scope:** `TaskService.updateTask` null-safety and `TaskControllerTest.update_taskNotFound_returns404()` activation only. | **Risk:** Low | **Version:** 1

#### Approach

- Reuse the existing not-found authority (`TaskNotFoundException` plus `GlobalExceptionHandler`) rather than adding a new controller error path; the GET path already proves this maps to 404 with `taskId`.
- Add the guard at the same service boundary where `getTask()` and `deleteTask()` already enforce missing-entity semantics, keeping the controller thin and the repository unchanged.
- Convert the dormant regression test into active coverage by removing `@Disabled`, removing the now-unused import, and asserting both the 404 status and the echoed `taskId`.
- Preserve all existing PUT behavior for known IDs and leave every other endpoint, DTO, model, repository, build, and handler untouched.

#### Implementation

##### 1. Guard missing tasks in TaskService.updateTask

**Files:** src/main/java/com/example/taskmanager/service/TaskService.java

**Changes:** In `updateTask(String id, CreateTaskRequest request)`, immediately after `Task existing = repository.findById(id)`, add a null check that throws `new TaskNotFoundException(id)` when `existing == null`; only then apply the title/description/priority mutations, timestamp update, save, and return. Do not change any other method.

**Edge cases:** Unknown id must throw the existing `TaskNotFoundException` with the requested id preserved; a known id must behave exactly as before; the repository still returns `null` by design and is not modified.

**Validation:** Source inspection plus the active regression test in step 2 exercises the unknown-id branch through the real HTTP layer and `GlobalExceptionHandler`.

##### 2. Activate the missing-id controller regression test

**Files:** src/test/java/com/example/taskmanager/controller/TaskControllerTest.java

**Changes:** Remove the `@Disabled` annotation and the `org.junit.jupiter.api.Disabled` import from `update_taskNotFound_returns404()`. Replace the Javadoc instruction to manually remove `@Disabled` with a description of the now-active regression coverage: a `PUT /tasks/non-existent-id` must return HTTP 404 and preserve the requested id in the error body. Keep the existing `status().isNotFound()` assertion and add `.andExpect(jsonPath("$.taskId").value("non-existent-id"))` to the same request chain. Do not change any other test method.

**Edge cases:** The test must not be skipped; it must assert both status and body; no other test method, endpoint, or assertion is changed.

**Validation:** The method executes in the default test run and fails if the service guard is absent (unhandled NullPointerException) or if `taskId` is not echoed.

#### Change Inventory

| Area | Files | Change |
|---|---|---|
| Service missing-id guard | src/main/java/com/example/taskmanager/service/TaskService.java | MODIFY `updateTask` to throw `TaskNotFoundException` when `findById` returns null |
| Controller regression coverage | src/test/java/com/example/taskmanager/controller/TaskControllerTest.java | MODIFY activate `update_taskNotFound_returns404`, assert `$.taskId`, update Javadoc |

#### Contracts

- HTTP `PUT /tasks/{id}` contract: for an unknown id the response must be HTTP 404 with the existing error body shape produced by `GlobalExceptionHandler` (`error`, `taskId`, `timestamp`), and `taskId` must equal the requested path id. Owning authority: `TaskController` plus `GlobalExceptionHandler`; outcome: preserved and now exercised for PUT.
- HTTP `PUT /tasks/{id}` existing-task contract: for a known id the response must remain HTTP 200 with the submitted title and priority reflected in the response. Owning authority: existing controller/service behavior; outcome: unchanged.
- Service missing-entity invariant: `TaskService` is responsible for translating a missing repository record into `TaskNotFoundException`; repository null-return semantics and interface stay unchanged.
- Test-suite contract: `TaskControllerTest.update_taskNotFound_returns404()` must be enabled and assert both HTTP 404 and `$.taskId == "non-existent-id"`; all pre-existing tests must remain green.

#### Authority Decisions

- `TaskNotFoundException` plus `GlobalExceptionHandler` remain the single canonical mapping from a missing task to HTTP 404; the implementation must not add a second error-mapping authority in the controller.
- `TaskRepository.findById` remains the canonical existence lookup and keeps returning `null`; no Optional wrapper, repository change, or persistence layer is introduced.
- The service layer owns missing-entity semantics consistently with `getTask()` and `deleteTask()`; the controller remains a thin adapter.
- The activated controller test is the regression authority for the PUT 404 contract; its assertions must not be weakened.

#### Acceptance Criteria

- [ ] `PUT /tasks/non-existent-id` returns HTTP 404.
- [ ] The 404 error body includes `taskId` equal to `non-existent-id`.
- [ ] `PUT /tasks/{existing-id}` still returns HTTP 200 with the submitted title and priority applied.
- [ ] `TaskControllerTest.update_taskNotFound_returns404()` is enabled (no `@Disabled`) and asserts both the 404 status and the `taskId` value.
- [ ] The test Javadoc describes the active regression coverage and contains no instruction to manually remove `@Disabled`.
- [ ] The full repository test suite run by `./mvnw test` completes without failures.

#### Verification

1. `npm run build --` — Source: `package.json#scripts.build` (runs `./mvnw verify`); expected: full Maven verification passes, including the active `TaskControllerTest#update_taskNotFound_returns404`.
2. `npm run test --` — Source: `package.json#scripts.test` (runs `./mvnw test`); expected: all tests pass, including the active `TaskControllerTest#update_taskNotFound_returns404`.
3. Claim 1 positive observable: the activated JUnit assertion `com.example.taskmanager.controller.TaskControllerTest#update_taskNotFound_returns404` observes HTTP 404 and `taskId == "non-existent-id"`. Concrete violating variant: delete the null check so `existing.setTitle(...)` dereferences null and raises an unhandled NullPointerException before any response is produced. Expected failure: that JUnit assertion fails because the request errors with an unhandled NullPointerException (a 5xx in a real container) and never yields the expected 404 response. Separate execution route: the `test` check candidate `vc_3f19a45cf6effbb244b4d9ec810d4093766d1e0eec1853f0a21367cc0cd5bf45` (`./mvnw test`, JUnit Surefire XML), distinct from the `build` positive check.
4. Claim 2 positive observable: the existing JUnit assertion `com.example.taskmanager.controller.TaskControllerTest#update_existing_task_returns_ok` observes HTTP 200 and the updated title and priority. Concrete violating variant: make `updateTask` always throw `TaskNotFoundException` (or return without applying mutations), so a known-id update no longer succeeds. Expected failure: that JUnit assertion fails on the faulty variant because the response status or the title/priority values no longer match. Separate execution route: the `build` check candidate `vc_753d3155403ed59a8c6868e0e70d077b0fef6720b0e7b1d10d9bce4fe8adacc9` (`./mvnw verify`, JUnit Surefire XML), distinct from the `test` positive check.
5. Discovery evidence: the compact status projection reports `discoveryHealth.status = available` with `healthy: true`, all 6 collectors complete and 0 failed, collected at `2026-11-24T17:09:29Z`. Discovery drift is `NOT_VERIFIED` in the compact projection (`status: not_checked`); recovery: run full `flowguard_status` or `/hydrate` to assess fresh repository drift before relying on discovery-dependent conclusions.
6. Full-suite completeness attestation is `NOT_VERIFIED`: the active build/test candidates do not declare `fullCheckScopeAttestation: full_check`, so no aggregate `suite` claim is declared; suite-wide success is observed only as check execution evidence.

```flowguard-evidence-design
{
  "version": 1,
  "claims": [
    {
      "authoritySectionId": "implementation-step-1",
      "statement": "A PUT /tasks/{id} request for an unknown task id returns HTTP 404 with a JSON error body whose taskId equals the requested id instead of propagating a NullPointerException as HTTP 500.",
      "positiveObservable": "TaskControllerTest#update_taskNotFound_returns404 asserts HTTP 404 and response body taskId 'non-existent-id' during the mvn verify build check.",
      "faultyVariant": "Remove the TaskService.updateTask null check so a missing repository result is dereferenced and raises an unhandled NullPointerException before any response is produced.",
      "expectedFailure": "The bound JUnit assertion for TaskControllerTest#update_taskNotFound_returns404 fails because the request errors with an unhandled NullPointerException (a 5xx in a real container) and never yields the expected 404 response.",
      "executionRoute": "vc_3f19a45cf6effbb244b4d9ec810d4093766d1e0eec1853f0a21367cc0cd5bf45"
    },
    {
      "authoritySectionId": "implementation-step-1",
      "statement": "A PUT /tasks/{id} request for an existing task still returns HTTP 200 with the submitted title and priority applied.",
      "positiveObservable": "TaskControllerTest#update_existing_task_returns_ok asserts HTTP 200 and the updated title and priority during the mvn test check.",
      "faultyVariant": "Change TaskService.updateTask to throw TaskNotFoundException unconditionally, so a known-id update no longer succeeds.",
      "expectedFailure": "The bound JUnit assertion for TaskControllerTest#update_existing_task_returns_ok fails because the observed status or the title/priority values no longer match the updated task.",
      "executionRoute": "vc_753d3155403ed59a8c6868e0e70d077b0fef6720b0e7b1d10d9bce4fe8adacc9"
    }
  ]
}
```

## Decision required

Plan decision required.
- `/approve` — approve the plan if it is complete and acceptable
- `/request-changes` — send the plan back for revision
- `/reject` — stop this task
